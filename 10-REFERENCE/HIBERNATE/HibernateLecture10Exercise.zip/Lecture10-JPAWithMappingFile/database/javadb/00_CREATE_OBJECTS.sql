run '01_ACCOUNT_OWNER.sql';

run '02_EBILLER.sql';

run '03_ACCOUNT.sql';

run '04_ACCOUNT_TRANSACTION.sql';

run '05_EBILL.sql';

run '06_ACCOUNT_ACCOUNT_OWNER.sql';

run '07_HIBERNATE_UNIQUE_KEY.sql';

run '08_ACCOUNT_EBILLER.sql';
