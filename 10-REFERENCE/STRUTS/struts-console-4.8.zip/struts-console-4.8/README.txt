***********************************************************************
ABOUT
***********************************************************************

The Struts Console is a FREE standalone Java Swing application for
managing Struts-based applications. With the Struts Console you can
visually edit Struts, Tiles and Validator configuration files.

The Struts Console also "plugs" into multiple, popular Java IDEs for
seamless management of Struts applications from one central development
tool.

Currently Supported IDEs
  + Borland JBuilder version 4.0 and higher
  + Eclipse version 1.0 and higher
  + IBM WebSphere Application Developer version 4.0.3 and higher
  + IntelliJ IDEA version 3.0 (build 668) and higher
  + NetBeans version 3.2 and higher
  + Oracle JDeveloper version 9i and higher
  + Sun One Studio (Forte) version 3.0 and higher



***********************************************************************
RUNNING
***********************************************************************

Windows
-----------------------------------------------------------------------
There are two ways to run the Struts Console on Windows machines:

1.) Using Windows explorer, navigate to the directory where you
    unzipped the Struts Console distribution to.  Go into the "bin"
    directory and double click on "console".

2.) Open a DOS command prompt window and navigate to the directory
    where you unzipped the Struts Console distribution to.  Go into the
    "bin" directory and type "console".


UNIX/Linux/Cygwin/...
-----------------------------------------------------------------------
Navigate to the directory where you unzipped the Struts Console
distribution to.  Go into the "bin" directory and run "console.sh".



***********************************************************************
GETTING HELP / SUBMITTING BUGS & FEATURES
***********************************************************************

If you need help first consult the help section of the documentation
under the "docs" directory.

Contact James Holmes, the author, for any questions about using the
software, any bugs you find or any features you would like to see added
to the software.

james@jamesholmes.com
