MyEclipse 7.0
Date: 6th December 2008

Select File >  Import > Existing Projects into Workspace, choose the "Select archive file"
option and point it to this zip file. Press Finish to import the restdemo project into your 
Eclipse workspace.