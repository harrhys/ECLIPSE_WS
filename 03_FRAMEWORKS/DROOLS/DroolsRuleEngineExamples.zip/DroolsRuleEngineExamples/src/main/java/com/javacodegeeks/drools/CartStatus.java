package com.javacodegeeks.drools;

public enum CartStatus {
NEW,
PROCESSED,
PENDING
}
