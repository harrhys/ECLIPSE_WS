@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.enterprise.javacodegeeks.com/")
package com.javacodegeeks.enterprise.ws;
